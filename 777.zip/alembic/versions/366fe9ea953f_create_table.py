"""create table

Revision ID: 366fe9ea953f
Revises: 
Create Date: 2019-09-04 16:05:27.264429

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '366fe9ea953f'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
